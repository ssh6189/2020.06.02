#include <CUnit/Basic.h>

int semanage_utilities_test_init(void);
int semanage_utilities_test_cleanup(void);
int semanage_utilities_add_tests(CU_pSuite suite);
