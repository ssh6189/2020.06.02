#ifndef _SEPOL_PORT_INTERNAL_H_
#define _SEPOL_PORT_INTERNAL_H_

#include <sepol/port_record.h>
#include <sepol/ports.h>

#endif
